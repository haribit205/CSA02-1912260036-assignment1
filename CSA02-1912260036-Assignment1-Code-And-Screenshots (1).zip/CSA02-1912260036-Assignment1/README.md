# CSA02-1912260036-Assignment1

**Student Name:** U. Hariharasudhan  
**Register Number:** 1912260036  
**Course:** CSA02 – C Programming (CO1)  
**Assignment Title:** Design, Implement and Validate a Reliable Billing Program for a Rural Electricity Co-operative  
**Compiler & Version:** `gcc (Debian 12.2.0-14+deb12u1) 12.2.0` (`-std=c11 -Wall -Wextra`)  

---

## Compilation & Execution Instructions

### Task 02 — Data Types, Register Rollover & 4,000-Bill Precision Test
```bash
cd Task02
gcc -Wall -Wextra -std=c11 task2_datatypes.c -o task2_datatypes
./task2_datatypes
```

### Task 03 — Centralized Tariff Constants & Slab Billing
```bash
cd Task03
gcc -Wall -Wextra -std=c11 task3_constants.c -o task3_constants
./task3_constants
```

### Task 04 — Safe Parenthesized Macros vs. `static inline` Functions
```bash
cd Task04
gcc -Wall -Wextra -std=c11 task4_macros.c -o task4_macros
./task4_macros
```

### Task 05 — Header Files, Include Guards & Conditional Compilation (`-DDEBUG`)
```bash
cd Task05
gcc -Wall -Wextra -std=c11 -DDEBUG task5_headers.c -o task5_debug
./task5_debug
```

### Task 06 & Task 07 — Formatted I/O, Input Validation & Type Conversion Surprises
```bash
cd Task06_07
gcc -Wall -Wextra -std=c11 task67_conv.c -o task67_conv
./task67_conv
```

### Task 08 — GCC Compilation Pipeline (`-E`, `-S`, `-c`, Linking)
```bash
cd Task08
gcc -E task3_constants.c -o task3.i
gcc -S task3_constants.c -o task3.s
gcc -c task3_constants.c -o task3.o
gcc task3.o -o task3_constants
```

### Task 09 & Task 10 — Complete Validation Suite & District Scale (4k / 60k / 800k)
```bash
cd Task09_10
gcc -Wall -Wextra -std=c11 task910_scale.c -o task910_scale
./task910_scale
```

### Task 12 — Day-4 Smart-Meter 64-bit Wh & Time-of-Day Peak Billing
```bash
cd Task12
gcc -Wall -Wextra -std=c11 task12_smart.c -o task12_smart
./task12_smart
```
